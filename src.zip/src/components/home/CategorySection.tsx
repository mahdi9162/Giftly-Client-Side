import Link from 'next/link';
import { ArrowUpRight, Cake, Gift, Heart, Pencil, User, Users } from 'lucide-react';
import Container from '../shared/Container';

const categories = [
  {
    id: 1,
    title: 'Birthday',
    description: 'Perfect picks to celebrate another year',
    href: '/shop?category=birthday',
    icon: Cake,
    iconBg: 'bg-orange-100',
    iconColor: 'text-orange-500',
  },
  {
    id: 2,
    title: 'Anniversary',
    description: 'Romantic gifts for special moments',
    href: '/shop?category=anniversary',
    icon: Heart,
    iconBg: 'bg-rose-100',
    iconColor: 'text-rose-500',
  },
  {
    id: 3,
    title: 'For Him',
    description: 'Curated gifts made for him',
    href: '/shop?category=for-him',
    icon: User,
    iconBg: 'bg-sky-100',
    iconColor: 'text-sky-500',
  },
  {
    id: 4,
    title: 'For Her',
    description: 'Thoughtful gifts made for her',
    href: '/shop?category=for-her',
    icon: Gift,
    iconBg: 'bg-pink-100',
    iconColor: 'text-pink-500',
  },
  {
    id: 5,
    title: 'Family',
    description: 'Meaningful gifts for everyone at home',
    href: '/shop?category=family',
    icon: Users,
    iconBg: 'bg-emerald-100',
    iconColor: 'text-emerald-500',
  },
  {
    id: 6,
    title: 'Personalized',
    description: 'Custom gifts with a personal touch',
    href: '/shop?category=personalized',
    icon: Pencil,
    iconBg: 'bg-violet-100',
    iconColor: 'text-violet-500',
  },
];

const CategorySection = () => {
  return (
   <Container>
      <section className="py-16 md:py-20">
        <div className="relative overflow-hidden rounded-4xl border border-rose-100/70 bg-linear-to-br from-white via-rose-50/50 to-violet-50/40 p-6 shadow-[0_24px_80px_rgba(15,23,42,0.06)] md:p-10 lg:p-14">
          {/* soft background glow */}
          <div className="pointer-events-none absolute -left-16 top-10 h-40 w-40 rounded-full bg-rose-200/20 blur-3xl" />
          <div className="pointer-events-none absolute -right-16 bottom-10 h-40 w-40 rounded-full bg-violet-200/20 blur-3xl" />

          {/* heading */}
          <div className="relative mx-auto max-w-2xl text-center">
            <p className="mb-3 inline-flex rounded-full border border-rose-200/70 bg-white/80 px-4 py-1 text-xs font-semibold uppercase tracking-[0.22em] text-rose-500 shadow-sm backdrop-blur-sm">
              Gift Categories
            </p>

            <h2 className="text-4xl font-bold tracking-tight text-slate-900 md:text-5xl">
              Explore Gift Categories
            </h2>

            <p className="mt-4 text-base leading-7 text-slate-500 md:text-lg">
              Browse curated picks by occasion, recipient, and gifting style.
            </p>
          </div>

          {/* cards */}
          <div className="relative mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {categories.map((category) => {
              const Icon = category.icon;

              return (
                <Link
                  key={category.id}
                  href={category.href}
                  className="group relative overflow-hidden rounded-[30px] border border-slate-200/80 bg-white p-7 shadow-[0_12px_30px_rgba(15,23,42,0.05)] transition-all duration-300 hover:-translate-y-2 hover:border-rose-200 hover:shadow-[0_22px_45px_rgba(244,114,182,0.12)]"
                >
                  {/* subtle top glow */}
                  <div className="absolute inset-x-0 top-0 h-20 bg-linear-to-b from-rose-50/60 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                  {/* top row */}
                  <div className="relative z-10 mb-8 flex items-start justify-between">
                    <div
                      className={`flex h-18 w-18 items-center justify-center rounded-[22px] ${category.iconBg} ring-1 ring-black/5 shadow-sm transition-all duration-300 group-hover:scale-110 group-hover:shadow-md`}
                    >
                      <Icon className={`h-8 w-8 ${category.iconColor}`} strokeWidth={2.2} />
                    </div>

                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-50 text-slate-400 transition-all duration-300 group-hover:bg-rose-50 group-hover:text-rose-500">
                      <ArrowUpRight className="h-4 w-4" />
                    </div>
                  </div>

                  {/* text */}
                  <div className="relative z-10 text-left">
                    <h3 className="text-2xl font-semibold tracking-tight text-slate-900 md:text-[28px]">
                      {category.title}
                    </h3>

                    <p className="mt-3 max-w-[24ch] text-sm leading-6 text-slate-500 md:text-[15px]">
                      {category.description}
                    </p>
                  </div>

                  {/* subtle bottom glow */}
                  <div className="absolute inset-x-10 bottom-0 h-px bg-linear-to-r from-transparent via-rose-300 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                </Link>
              );
            })}
          </div>
        </div>
      </section>
    </Container>
  );
};

export default CategorySection;
